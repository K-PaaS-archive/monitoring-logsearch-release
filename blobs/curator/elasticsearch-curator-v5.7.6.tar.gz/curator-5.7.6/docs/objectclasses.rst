.. _objectclasses:

Object Classes
==============

* `IndexList`_
* `SnapshotList`_


IndexList
---------

.. autoclass:: curator.indexlist.IndexList
   :members:

SnapshotList
------------

.. autoclass:: curator.snapshotlist.SnapshotList
   :members:
